package view;

import dao.BarangDAO;
import model.Barang;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FormBarang extends JFrame {
    private BarangDAO barangDAO;
    
    private JTextField txtKodeBarang, txtNamaBarang, txtStok;
    private JComboBox<String> jComboBoxKategori;
    private JTable jTableBarang;
    private JButton btnSimpan, btnUbah, btnHapus, btnBersihkan;

    public FormBarang() {
        barangDAO = new BarangDAO();
        initUI();
        setupComboBox();
        loadTable();
    }

    private void initUI() {
        setTitle("Pengelolaan Data Barang Laboratorium");
        setSize(550, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        JLabel lblTitle = new JLabel("PENGELOLAAN DATA BARANG LABORATORIUM");
        lblTitle.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
        lblTitle.setBounds(25, 20, 400, 25);
        add(lblTitle);

        JLabel lblKode = new JLabel("Kode Barang");
        lblKode.setBounds(25, 60, 100, 25);
        add(lblKode);

        txtKodeBarang = new JTextField();
        txtKodeBarang.setBounds(140, 60, 375, 25);
        add(txtKodeBarang);

        JLabel lblNama = new JLabel("Nama Barang");
        lblNama.setBounds(25, 100, 100, 25);
        add(lblNama);

        txtNamaBarang = new JTextField();
        txtNamaBarang.setBounds(140, 100, 375, 25);
        add(txtNamaBarang);

        JLabel lblKategori = new JLabel("Kategori");
        lblKategori.setBounds(25, 140, 100, 25);
        add(lblKategori);

        jComboBoxKategori = new JComboBox<>();
        jComboBoxKategori.setBounds(140, 140, 375, 25);
        add(jComboBoxKategori);

        JLabel lblStok = new JLabel("Stok");
        lblStok.setBounds(25, 180, 100, 25);
        add(lblStok);

        txtStok = new JTextField();
        txtStok.setBounds(140, 180, 375, 25);
        add(txtStok);

        btnSimpan = new JButton("Simpan");
        btnSimpan.setBounds(25, 225, 110, 30);
        add(btnSimpan);

        btnUbah = new JButton("Ubah");
        btnUbah.setBounds(153, 225, 110, 30);
        add(btnUbah);

        btnHapus = new JButton("Hapus");
        btnHapus.setBounds(281, 225, 110, 30);
        add(btnHapus);

        btnBersihkan = new JButton("Bersihkan");
        btnBersihkan.setBounds(405, 225, 110, 30);
        add(btnBersihkan);

        jTableBarang = new JTable(new DefaultTableModel(
            new Object[][]{},
            new String[]{"Kode Barang", "Nama Barang", "Kategori", "Stok"}
        ));
        JScrollPane scrollPane = new JScrollPane(jTableBarang);
        scrollPane.setBounds(25, 275, 490, 180);
        add(scrollPane);

        // Event Handling Tombol
        btnSimpan.addActionListener(e -> btnSimpanActionPerformed());
        btnUbah.addActionListener(e -> btnUbahActionPerformed());
        btnHapus.addActionListener(e -> btnHapusActionPerformed());
        btnBersihkan.addActionListener(e -> clearForm());

        // Event Handling Klik Baris pada JTable (Langkah 6)
        jTableBarang.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = jTableBarang.getSelectedRow();
                if (row != -1) {
                    txtKodeBarang.setText(jTableBarang.getValueAt(row, 0).toString());
                    txtNamaBarang.setText(jTableBarang.getValueAt(row, 1).toString());
                    jComboBoxKategori.setSelectedItem(jTableBarang.getValueAt(row, 2).toString());
                    txtStok.setText(jTableBarang.getValueAt(row, 3).toString());
                    
                    // Kunci Kode Barang agar Primary Key tidak berubah saat mode edit
                    txtKodeBarang.setEnabled(false); 
                }
            }
        });
    }

    private void setupComboBox() {
        jComboBoxKategori.removeAllItems();
        jComboBoxKategori.addItem("Komputer");
        jComboBoxKategori.addItem("Jaringan");
        jComboBoxKategori.addItem("Alat Ukur");
    }

    public void loadTable() {
        DefaultTableModel model = (DefaultTableModel) jTableBarang.getModel();
        model.setRowCount(0);
        List<Barang> list = barangDAO.getAll();
        for (Barang b : list) {
            model.addRow(new Object[]{
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok()
            });
        }
    }

    private void clearForm() {
        txtKodeBarang.setText("");
        txtNamaBarang.setText("");
        txtStok.setText("");
        jComboBoxKategori.setSelectedIndex(0);
        txtKodeBarang.setEnabled(true); // Aktifkan kembali untuk input baru
        jTableBarang.clearSelection();
    }

    // Tombol Simpan dengan Validasi (Langkah 5)
    private void btnSimpanActionPerformed() {
        String kode = txtKodeBarang.getText().trim();
        String nama = txtNamaBarang.getText().trim();
        String kategori = jComboBoxKategori.getSelectedItem().toString();
        String strStok = txtStok.getText().trim();

        if (kode.isEmpty() || nama.isEmpty() || strStok.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kode, Nama, dan Stok tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int stok;
        try {
            stok = Integer.parseInt(strStok);
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok harus berupa angka >= 0!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus berupa angka yang valid!", "Kesalahan Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Barang barang = new Barang(kode, nama, kategori, stok);
        boolean sukses = barangDAO.insert(barang);

        if (sukses) {
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
            loadTable();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal menyimpan data (Kemungkinan Kode Barang sudah ada).", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Tombol Ubah (Langkah 7)
    private void btnUbahActionPerformed() {
        String kode = txtKodeBarang.getText().trim();
        String nama = txtNamaBarang.getText().trim();
        String kategori = jComboBoxKategori.getSelectedItem().toString();
        String strStok = txtStok.getText().trim();

        if (txtKodeBarang.isEnabled()) {
            JOptionPane.showMessageDialog(this, "Pilih data pada tabel terlebih dahulu yang akan diubah!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (nama.isEmpty() || strStok.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama dan Stok tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int stok;
        try {
            stok = Integer.parseInt(strStok);
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok harus berupa angka >= 0!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus berupa angka yang valid!", "Kesalahan Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Barang barang = new Barang(kode, nama, kategori, stok);
        boolean sukses = barangDAO.update(barang);

        if (sukses) {
            JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
            loadTable();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal mengubah data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Tombol Hapus dengan Konfirmasi (Langkah 7)
    private void btnHapusActionPerformed() {
        String kode = txtKodeBarang.getText().trim();

        if (txtKodeBarang.isEnabled()) {
            JOptionPane.showMessageDialog(this, "Pilih data pada tabel terlebih dahulu yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int konfirmasi = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus barang dengan kode: " + kode + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (konfirmasi == JOptionPane.YES_OPTION) {
            boolean sukses = barangDAO.delete(kode);
            if (sukses) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                loadTable();
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            new FormBarang().setVisible(true);
        });
    }
}